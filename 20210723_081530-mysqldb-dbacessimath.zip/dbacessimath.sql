-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: mysql742.umbler.com    Database: dbacessimath
-- ------------------------------------------------------
-- Server version	5.6.50

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `dbacessimath`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `dbacessimath` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `dbacessimath`;

--
-- Table structure for table `atividades`
--

DROP TABLE IF EXISTS `atividades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atividades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nivel` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `contemImgDesc` tinyint(1) NOT NULL,
  `contemImgRes` tinyint(1) NOT NULL,
  `descricaoImg` varchar(255) NOT NULL,
  `respostaA` varchar(255) NOT NULL,
  `respostaB` varchar(255) NOT NULL,
  `respostaC` varchar(255) NOT NULL,
  `respostaD` varchar(255) NOT NULL,
  `respostaA_img` varchar(255) NOT NULL,
  `respostaB_img` varchar(255) NOT NULL,
  `respostaC_img` varchar(255) NOT NULL,
  `respostaD_img` varchar(255) NOT NULL,
  `respostaCorreta` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atividades`
--

LOCK TABLES `atividades` WRITE;
/*!40000 ALTER TABLE `atividades` DISABLE KEYS */;
INSERT INTO `atividades` VALUES (1,1,'Reconhecendo o número 1','Qual imagem tem 1 morango?',0,1,'','','','','','morango2.png','morango4.png','morango1.png','morango3.png','c'),(2,1,'Reconhecendo o número 2','Qual imagem tem 2 cachorros?',0,1,'','','','','','cachorro3.png','cachorro5.png','cachorro1.png','cachorro2.png','d'),(3,1,'Reconhecendo o número 3','Qual imagem tem 3 bolas?',0,1,'','','','','','bola3.png','bola4.png','bola2.png','bola5.png','a'),(4,1,'Reconhecendo o número 4','Qual imagem tem 4 abelhas?',0,1,'','','','','','abelha2.png','abelha6.png','abelha4.png','abelha5.png','c'),(5,1,'Reconhecendo o número 5','Qual imagem tem 5 carros?',0,1,'','','','','','carro6.png','carro5.png','carro3.png','carro7.png','b'),(6,1,'Reconhecendo o número 6','Qual imagem tem 6 passarinhos?',0,1,'','','','','','passaro6.png','passaro3.png','passaro7.png','passaro5.png','a'),(7,1,'Reconhecendo o número 7','Qual imagem tem 7 fatias de pizza?',0,1,'','','','','','pizza8.png','pizza9.png','pizza7.png','pizza5.png','c'),(8,1,'Reconhecendo o número 8','Qual imagem tem 8 gatos?',0,1,'','','','','','gato9.png','gato6.png','gato7.png','gato8.png','d'),(9,1,'Reconhecendo o número 9','Qual imagem tem 9 maças?',0,1,'','','','','','maca8.png','maca9.png','maca6.png','maca7.png','b'),(10,2,'Aprendendo a somar','Quanto é 1 + 1?',1,1,'borboleta-1mais1.png','4','1','3','2','borboleta4.png','borboleta1.png','borboleta3.png','borboleta2.png','d'),(11,2,'Aprendendo a somar','Qual o resultado da soma abaixo?',1,1,'bola-3mais1.png','6','5','4','3','bola6.png','bola5.png','bola4.png','bola3.png','c'),(12,2,'Aprendendo a somar','Quanto é 3 + 3?',1,1,'joana-3mais3.png','3','4','6','5','joana3.png','joana4.png','joana6.png','joana5.png','c'),(13,2,'Aprendendo a somar','Quanto é 3 + 2?',1,1,'lapis-3mais2.png','3','5','6','4','lapis3.png','lapis5.png','lapis6.png','lapis4.png','b'),(14,2,'Aprendendo a somar','Qual soma resulta em 7?',1,1,'flor7.png','2 + 5','4 + 2','3 + 3','5 + 3','flor-2mais5.png','flor-4mais2.png','flor-3mais3.png','flor-5mais3.png','a'),(15,2,'Aprendendo a somar','Qual soma resulta em 6?',1,1,'sorvete6.png','2 + 1','3 + 3','2 + 5','1 + 3','sorvete-2mais1.png','sorvete-3mais3.png','sorvete-2mais5.png','sorvete-1mais3.png','b'),(16,2,'Aprendendo a somar','Quanto é 2 + 1?',1,1,'hamb-2mais1.png','3','2','4','5','hamb3.png','hamb2.png','hamb4.png','hamb5.png','a'),(17,2,'Aprendendo a somar','Qual soma resulta em 4?',1,1,'peixe4.png','2 + 3','2 + 2','4 + 1','3 + 2','peixe-2mais3.png','peixe-2mais2.png','peixe-4mais1.png','peixe-3mais2.png','b'),(18,2,'Aprendendo a somar','Qual o resultado da soma abaixo?',1,1,'cachorro-2mais2.png','4','3','5','6','cachorro4.png','cachorro3.png','cachorro5.png','cachorro6.png','a'),(19,2,'Aprendendo a somar','Qual soma resulta em 8?',1,1,'ovelha8.png','4 + 2','3 + 4','2 + 1','5 + 3','ovelha-4mais2.png','ovelha-3mais4.png','ovelha-2mais1.png','ovelha-5mais3.png','d'),(20,3,'Aprendendo a subtrair','Qual o resultado da subtração abaixo?',1,1,'casa-4menos2.png','2','4','3','5','casa2.png','casa4.png','casa3.png','casa5.png','a'),(21,3,'Aprendendo a subtrair','Quanto é 2 - 1?',1,1,'uva-2menos1.png','2','3','1','4','uva2.png','uva3.png','uva1.png','uva4.png','c'),(22,3,'Aprendendo a subtrair','Qual subtração resulta em 4?',1,1,'urso4.png','5 - 1','6 - 3','7 - 4','8 - 3','urso-5menos1.png','urso-6menos3.png','urso-7menos4.png','urso-8menos3.png','a'),(23,3,'Aprendendo a subtrair','Qual o resultado da subtração abaixo?',1,1,'unicornio-3menos2.png','1','3','2','4','unicornio1.png','unicornio3.png','unicornio2.png','unicornio4.png','a'),(24,3,'Aprendendo a subtrair','Quanto é 5 - 3?',1,1,'banana-5menos3.png','4','1','2','3','banana4.png','banana1.png','banana2.png','banana3.png','c'),(25,3,'Aprendendo a subtrair','Qual subtração resulta em 2?',1,1,'arvore2.png','5 - 4','4 - 3','6 - 4','5 - 3','arvore-5menos4.png','arvore-4menos3.png','arvore-6menos4.png','arvore-5menos3.png','d'),(26,3,'Aprendendo a subtrair','Quanto é 6 - 3?',1,1,'coelho-6menos3.png','4','2','5','3','coelho4.png','coelho2.png','coelho5.png','coelho3.png','d'),(27,3,'Aprendendo a subtrair','Quanto é 6 - 2?',1,1,'cachorro-6menos2.png','6','4','3','7','cachorro6.png','cachorro4.png','cachorro3.png','cachorro7.png','b'),(28,3,'Aprendendo a subtrair','Qual subtração resulta em 6?',1,1,'melancia6.png','7 - 3','8 - 3','8 - 2','9 - 4','melancia-7menos3.png','melancia-8menos3.png','melancia-8menos2.png','melancia-9menos4.png','c'),(29,3,'Aprendendo a subtrair','Qual o resultado da subtração abaixo?',1,1,'golfinho-9menos4.png','6','5','3','7','golfinho6.png','golfinho5.png','golfinho3.png','golfinho7.png','b'),(30,4,'Aprendendo a multiplicar','Qual multiplicação resulta em 9?',1,1,'carro9.png','4 x 2','5 x 1','3 x 2','1 x 9','carro-4vezes2.png','carro-5vezes1.png','carro-3vezes2.png','carro-1vezes9.png','d'),(31,4,'Aprendendo a multiplicar','Quanto é 5 x 1?',1,1,'morango-5vezes1.png','1','5','4','3','morango1.png','morango5.png','morango4.png','morango3.png','b'),(32,4,'Aprendendo a multiplicar','Qual o resultado da multiplicação abaixo?',1,1,'passaro-4vezes2.png','6','8','7','9','passaro6.png','passaro8.png','passaro7.png','passaro9.png','b'),(33,4,'Aprendendo a multiplicar','Quanto é 3 x 2?',1,1,'abelha-3vezes2.png','6','5','8','4','abelha6.png','abelha5.png','abelha8.png','abelha4.png','a'),(34,4,'Aprendendo a multiplicar','Qual multiplicação resulta em 8?',1,1,'coelho8.png','3 x 1','3 x 3','4 x 2','5 x 1','coelho-3vezes1.png','coelho-3vezes3.png','coelho-4vezes2.png','coelho-5vezes1.png','c'),(35,4,'Aprendendo a multiplicar','Qual o resultado da multiplicação abaixo?',1,1,'aviao-3vezes3.png','9','7','6','8','aviao9.png','aviao7.png','aviao6.png','aviao8.png','a'),(36,4,'Aprendendo a multiplicar','Quanto é 4 x 2?',1,1,'unicornio-4vezes2.png','7','6','9','8','unicornio7.png','unicornio6.png','unicornio9.png','unicornio8.png','d'),(37,4,'Aprendendo a multiplicar','Qual o resultado da multiplicação abaixo?',1,1,'golfinho-1vezes2.png','3','4','1','2','golfinho3.png','golfinho4.png','golfinho1.png','golfinho2.png','d'),(38,4,'Aprendendo a multiplicar','Qual multiplicação resulta em 7?',1,1,'sorvete7.png','1 x 7','3 x 2','4 x 2','1 x 6','sorvete-1vezes7.png','sorvete-3vezes2.png','sorvete-4vezes2.png','sorvete-1vezes6.png','a'),(39,4,'Aprendendo a multiplicar','Quanto é 2 x 4?',1,1,'sol-2vezes4.png','5','8','9','6','sol5.png','sol8.png','sol9.png','sol6.png','b'),(40,5,'Aprendendo a dividir','Qual o resultado da divisão abaixo?',1,1,'arvore-6dividido1.png','8','6','4','5','arvore8.png','arvore6.png','arvore4.png','arvore5.png','b'),(41,5,'Aprendendo a dividir','Quanto é 8 ÷ 4?',1,1,'peixe-8dividido4.png','4','1','3','2','peixe4.png','peixe1.png','peixe3.png','peixe2.png','d'),(42,5,'Aprendendo a dividir','Qual divisão resulta em 2?',1,1,'urso2.png','4 ÷ 1','4 ÷ 2','8 ÷ 2','6 ÷ 3','urso-4dividido1.png','urso-4dividido2.png','urso-8dividido2.png','urso-6dividido3.png','b'),(43,5,'Aprendendo a dividir','Qual o resultado da divisão abaixo?',1,1,'sorvete-8dividido2.png','4','3','6','2','sorvete4.png','sorvete3.png','sorvete6.png','sorvete2.png','a'),(44,5,'Aprendendo a dividir','Quanto é 6 dividido por 2?',1,1,'borboleta-6dividido2.png','2','6','4','3','borboleta2.png','borboleta6.png','borboleta4.png','borboleta3.png','d'),(45,5,'Aprendendo a dividir','Qual divisão resulta em 3?',1,1,'urso3.png','6 ÷ 3','4 ÷ 2','9 ÷ 3','6 ÷ 1','urso-6dividido3.png','urso-4dividido2.png','urso-9dividido3.png','urso-6dividido1.png','c'),(46,5,'Aprendendo a dividir','Qual o resultado da divisão abaixo?',1,1,'casa-8dividido1.png','4','6','9','8','casa4.png','casa6.png','casa9.png','casa8.png','d'),(47,5,'Aprendendo a dividir','Quanto é 9 dividido por 1?',1,1,'gato-9dividido1.png','8','5','9','7','gato8.png','gato5.png','gato9.png','gato7.png','c'),(48,5,'Aprendendo a dividir','Qual divisão resulta em 2?',1,1,'melancia2.png','6 ÷ 3','8 ÷ 2','4 ÷ 1','6 ÷ 2','melancia-6dividido3.png','melancia-8dividido2.png','melancia-4dividido1.png','melancia-6dividido2.png','a'),(49,5,'Aprendendo a dividir','Qual o resultado da divisão abaixo?',1,1,'ovelha-9dividido3.png','5','3','4','6','ovelha5.png','ovelha3.png','ovelha4.png','ovelha6.png','b');
/*!40000 ALTER TABLE `atividades` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-23  8:15:31
